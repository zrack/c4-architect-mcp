# From a Kafka event to an Oracle record

Seven views of a three-tier application. Follow two entry paths: a person using the web app and an event arriving through Kafka. The specified persistence path runs from Kafka through the application server to Oracle RAC.

[Open the standalone illustrated walkthrough](Walkthrough.html) · [Print the eight-page PDF](Walkthrough.pdf)

## Modeling assumptions

- Working boundary: Kafka supplies the event feed from outside the application. A separate eventing service and its operator still need confirmation.
- The model groups the logical datastore with the application. Responsibility for operating Kafka and Oracle RAC is open.
- The component names, code contracts and generic web response are design proposals. No implementation or production inventory was supplied.

## Diagram index

| Order | View | Scope | Editable model |
| ---: | --- | --- | --- |
| 1 | [System Context](diagrams/01-context.svg) | Direct actors, software system and event feed. | [Source](diagrams/01-context.json) |
| 2 | [Container](diagrams/02-container.svg) | Three logical tiers and their dependencies. | [Source](diagrams/02-container.json) |
| 3 | [Data Flow](diagrams/03-data-flow.svg) | Information entering and leaving the application. | [Source](diagrams/03-data-flow.json) |
| 4 | [Component](diagrams/04-component.svg) | Candidate responsibilities inside the application server. | [Source](diagrams/04-component.json) |
| 5 | [Code](diagrams/05-code.svg) | Candidate contracts inside the event processor. | [Source](diagrams/05-code.json) |
| 6 | [Deployment](diagrams/06-deployment.svg) | Logical placement and the shared Oracle database. | [Source](diagrams/06-deployment.json) |
| 7 | [System Landscape](diagrams/07-system-landscape.svg) | Handoffs across the known integration neighborhood. | [Source](diagrams/07-system-landscape.json) |

## 1. System Context

Who uses the application, and what comes in from outside?

![System Context](diagrams/01-context.png)

A web user interacts with the application. Kafka makes inbound events available to it. “Event records application” is a working name for the system that accepts web requests and stores event-derived records.

As a first-time reader I can identify both entry paths. I still cannot name the user’s job, the business event, or the outcome that would tell the user the system worked. A web click and an incoming event may occur independently.

## 2. Container

Where does each of the three tiers begin and end?

![Container](diagrams/02-container.png)

Follow a web request from the Web app in tier 1 to the Application server in tier 2. The server also consumes events from Kafka and writes records to the Application datastore in tier 3. Oracle RAC hosts that datastore.

Kafka is drawn beside the three tiers as an integration platform. The server-to-Kafka arrow reads “consumes events from.” It identifies the client of the feed. The next view follows the event payload in the other direction.

## 3. Data Flow

Which data crosses each interface, and which path reaches Oracle?

![Data Flow](diagrams/03-data-flow.png)

[Explore the flows and select a process](diagrams/03-data-flow.html) · [Edit the data-flow model](diagrams/03-data-flow.json)

On the right, follow R01–R04 from the web user through the web app to the application server and back. On the left, Kafka supplies an event record (R05). The application server processes it and writes an event-derived record (R06) to Oracle RAC.

The generic web response makes the exchange legible while its contents remain open. Only the event path has a specified database write. A screen that reads back the stored record would need a confirmed user story, query and freshness requirement.

## 4. Component

Which part of the application server owns each responsibility?

![Component](diagrams/04-component.png)

The proposed Web request handler owns the web exchange. A Kafka consumer hands an event to the Event processor. The processor maps it and asks the Record repository to persist the result. Those four components belong inside the Application server.

This gives a team two distinct places to start a change. A new screen operation starts at the request handler. A change to the meaning of an incoming event starts at the processor. Whether the consumer shares a process or scales separately is still a deployment decision.

## 5. Code

What contract would let us test one event without a running database?

![Code](diagrams/05-code.png)

In this proposed design, process(event, writer) accepts an InboundEvent. It calls toStoredRecord(event) and then RecordWriter.save(record). The Record repository supplies that writer in production. A test could supply a recording writer and check the record it received.

This sketch gives us names for the input, the stored result and the write interface. It leaves the business fields and event identity open. If Oracle commits a write and the consumer restarts before recording its Kafka position, should replay be harmless, rejected or reconciled?

## 6. Deployment

Where would the software run, and how would it reach Oracle RAC?

![Deployment](diagrams/06-deployment.png)

The Web app uses a web runtime and calls the Application server in its runtime. The server consumes from Kafka and connects to a logical Oracle database service. Eligible RAC instances can serve that service and access one shared Oracle database.

This is a logical deployment. The database service names a connection target. A production diagram needs the hosting environment, runtime and RAC inventory, placement across failure domains, and recovery objectives. The diagram makes no promise about surviving a site outage.

## 7. System Landscape

Who participates before the event reaches this application?

![System Landscape](diagrams/07-system-landscape.png)

Start one system upstream. A producer with an unknown identity publishes to Kafka. Kafka makes those events available to the Event records application. The Web user accesses the application separately.

Context established the application’s direct neighbors. Landscape exposes the producer-to-Kafka handoff and the missing owner of the event contract. If “eventing system” means a separate bridge, it belongs on this map and its handoff must also appear in the data-flow and deployment views.

## Decisions to confirm

- **What does the web user need to accomplish after an event is processed?** A read-back requirement adds a query from the server to Oracle. The acceptable delay determines what the screen can promise.
- **Is Kafka the eventing system, or is there a separate integration service? Who publishes the event?** This establishes system boundaries, owners, and the connection the application server actually uses.
- **Can you give one real event and the Oracle row or rows it should produce?** The event identity, schema, key and update rule turn the proposed mapping and writer into implementable code.
- **What should happen on a replay, an out-of-order event, or a failed Oracle write?** The answer determines the transaction boundary, when the consumer can checkpoint its position, and the retry or reconciliation policy.
- **For which environment should we draw the production deployment, and what failures must it tolerate?** Hosting, worker placement, expected volume and lag, Kafka topology, RAC services and instances, and recovery objectives determine the physical design.

## How to edit the diagrams

Open Walkthrough.html in a browser for the seven views in reading order. Each of the seven diagrams has an editable JSON file, a PNG, a scalable SVG, Mermaid Markdown and an interactive HTML view. Select a node in an interactive view to highlight its connections.

With a built C4 Architect checkout, run the following from its root, replacing the example paths with the location of the extracted model and your desired Markdown output.

```sh
node dist/index.js render-diagram /path/to/diagrams/02-container.json --out /path/to/container.md
```

To render the data-flow example with native data-flow support, run the same command on the third model.

```sh
node dist/index.js render-diagram /path/to/diagrams/03-data-flow.json --out /path/to/data-flow.md
```

## References

- [C4 model — System Context](https://c4model.com/diagrams/system-context)
- [C4 model — System Landscape](https://c4model.com/diagrams/system-landscape)
- [Apache Kafka — consumer position and delivery semantics](https://kafka.apache.org/41/design/design/)
- [Oracle — RAC database instances and services](https://docs.oracle.com/en/database/oracle/oracle-database/19/racad/introduction-to-oracle-rac.html)

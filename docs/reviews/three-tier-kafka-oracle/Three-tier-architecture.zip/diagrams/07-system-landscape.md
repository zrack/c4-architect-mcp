# The event integration landscape

Known integration neighborhood · system owners to confirm

![Compact C4 diagram](07-system-landscape.png)

[Interactive view](07-system-landscape.html) · [Scalable SVG](07-system-landscape.svg)

<details>
<summary>Mermaid source export</summary>

```mermaid
---
title: "The event integration landscape"
config:
  theme: base
  themeVariables:
    primaryTextColor: '#15243a'
    lineColor: '#374151'
    edgeLabelBackground: '#ffffff'
  themeCSS: '.edgeLabel rect { opacity: 1 !important; fill: #ffffff !important; }'
  flowchart:
    htmlLabels: false
    wrappingWidth: 320
    nodeSpacing: 160
    rankSpacing: 180
    curve: bumpY
---
flowchart TB
  %% C4Landscape: C4 types with automatic graph layout
  n0["«person»<br/>Web user<br/>#91;Business role to confirm#93;<br/>Someone using the web app. Exact<br/>role and task are open."]
  n1["«external system»<br/>Upstream event producer<br/>#91;Identity to confirm#93;<br/>Placeholder for the system that<br/>publishes the inbound events;<br/>more than one publisher is<br/>possible."]
  n2["«external system»<br/>Kafka<br/>#91;Event platform#93;<br/>Carries events consumed by the<br/>application. A separate upstream<br/>eventing service is an open<br/>question."]
  n3["«software system»<br/>Event records application<br/>#91;Serves web requests and stores<br/>incoming event records#93;<br/>Working name for the<br/>application. The brief does not<br/>identify the business domain."]

  n1 -->|"Publishes inbound<br/>events"| n2
  n2 -->|"Makes events available"| n3
  n0 -->|"Uses the web interface"| n3

  classDef internal fill:#e7f0fb,stroke:#3c6fa9,color:#15243a
  classDef external fill:#f0f2f5,stroke:#737d8b,color:#15243a
  classDef person fill:#dbeafe,stroke:#3c6fa9,color:#15243a
  class n0 person
  class n1 external
  class n2 external
  class n3 internal
```

</details>

## Relationships

| ID | From | To | Action | Technology |
|---|---|---|---|---|
| R01 | producer | kafka | Publishes inbound events |  |
| R02 | kafka | application | Makes events available |  |
| R03 | web-user | application | Uses the web interface |  |

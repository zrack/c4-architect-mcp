# Inside the event processor

Proposed code contracts for one event

![Compact C4 diagram](05-code.png)

[Interactive view](05-code.html) · [Scalable SVG](05-code.svg)

<details>
<summary>Mermaid source export</summary>

```mermaid
---
title: "Inside the event processor"
config:
  theme: base
  themeVariables:
    primaryTextColor: '#15243a'
    lineColor: '#374151'
    edgeLabelBackground: '#ffffff'
  themeCSS: '.edgeLabel rect { opacity: 1 !important; fill: #ffffff !important; }'
  flowchart:
    htmlLabels: false
    wrappingWidth: 320
    nodeSpacing: 160
    rankSpacing: 180
    curve: bumpY
---
flowchart TB
  %% C4Code: C4 types with automatic graph layout
  n0["«type»<br/>InboundEvent<br/>#91;Input from the consumer#93;<br/>The event schema, identity and<br/>business fields are open."]
  n1["«function»<br/>process<br/>#91;process(event, writer)#93;<br/>Coordinates one proposed<br/>processing attempt."]
  n2["«function»<br/>toStoredRecord<br/>#91;toStoredRecord(event)#93;<br/>Converts an accepted event into<br/>the application record."]
  n3["«type»<br/>StoredRecord<br/>#91;Data to persist#93;<br/>Field mapping and record<br/>identity depend on the event<br/>contract."]
  n4["«interface»<br/>RecordWriter<br/>#91;save(record)#93;<br/>The record repository implements<br/>this port. Success and failure<br/>semantics need agreement."]

  n1 -->|"Accepts"| n0
  n1 -->|"Calls to map the event"| n2
  n2 -->|"Returns"| n3
  n1 -->|"Calls save(record)"| n4
  n4 -->|"Accepts for storage"| n3

  classDef internal fill:#e7f0fb,stroke:#3c6fa9,color:#15243a
  classDef external fill:#f0f2f5,stroke:#737d8b,color:#15243a
  classDef person fill:#dbeafe,stroke:#3c6fa9,color:#15243a
  class n0 internal
  class n1 internal
  class n2 internal
  class n3 internal
  class n4 internal
```

</details>

## Relationships

| ID | From | To | Action | Technology |
|---|---|---|---|---|
| R01 | proc | event | Accepts |  |
| R02 | proc | map | Calls to map the event |  |
| R03 | map | record | Returns |  |
| R04 | proc | writer | Calls save(record) |  |
| R05 | writer | record | Accepts for storage |  |

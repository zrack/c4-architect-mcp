# Inside the application server

Four proposed components inside tier 2

![Compact C4 diagram](04-component.png)

[Interactive view](04-component.html) · [Scalable SVG](04-component.svg)

<details>
<summary>Mermaid source export</summary>

```mermaid
---
title: "Inside the application server"
config:
  theme: base
  themeVariables:
    primaryTextColor: '#15243a'
    lineColor: '#374151'
    edgeLabelBackground: '#ffffff'
  themeCSS: '.edgeLabel rect { opacity: 1 !important; fill: #ffffff !important; }'
  flowchart:
    htmlLabels: false
    wrappingWidth: 320
    nodeSpacing: 160
    rankSpacing: 180
    curve: bumpY
---
flowchart TB
  %% C4Component: C4 types with automatic graph layout
  n0["«container»<br/>Web app<br/>#91;Tier 1 · Presentation#93;<br/>Receives user input; hosting<br/>style and user operations are<br/>open."]
  n1["«component»<br/>Web request handler<br/>#91;Handles a web request#93;"]
  n2["«component»<br/>Kafka consumer<br/>#91;Reads inbound events#93;"]
  n3["«component»<br/>Event processor<br/>#91;Maps an event to a record#93;"]
  n4["«component»<br/>Record repository<br/>#91;Writes to the datastore#93;"]
  n5["«external system»<br/>Kafka<br/>#91;Event platform#93;<br/>Carries events consumed by the<br/>application. A separate upstream<br/>eventing service is an open<br/>question."]
  n6[("«database»<br/>Application datastore<br/>#91;Tier 3 · Oracle RAC#93;<br/>One logical application<br/>datastore hosted by Oracle RAC.<br/>Schema and operational ownership<br/>are open.")]

  n0 -->|"Sends a web request"| n1
  n2 -->|"Consumes events from"| n5
  n2 -->|"Passes the event"| n3
  n3 -->|"Requests a record<br/>write"| n4
  n4 -->|"Persists the record"| n6

  classDef internal fill:#e7f0fb,stroke:#3c6fa9,color:#15243a
  classDef external fill:#f0f2f5,stroke:#737d8b,color:#15243a
  classDef person fill:#dbeafe,stroke:#3c6fa9,color:#15243a
  class n0 internal
  class n1 internal
  class n2 internal
  class n3 internal
  class n4 internal
  class n5 external
  class n6 internal
```

</details>

## Relationships

| ID | From | To | Action | Technology |
|---|---|---|---|---|
| R01 | web-app | web-handler | Sends a web request |  |
| R02 | consumer | kafka | Consumes events from |  |
| R03 | consumer | processor | Passes the event |  |
| R04 | processor | repository | Requests a record write |  |
| R05 | repository | store | Persists the record |  |

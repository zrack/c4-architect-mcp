# Request and event data

Web responses are illustrative. Only the inbound event path writes to Oracle.

![Data-flow diagram](03-data-flow.png)

[Interactive view](03-data-flow.html) · [Scalable SVG](03-data-flow.svg)

<details>
<summary>Mermaid source export</summary>

```mermaid
---
title: "Request and event data"
config:
  theme: base
  themeVariables:
    primaryTextColor: '#15243a'
    lineColor: '#374151'
    edgeLabelBackground: '#ffffff'
  themeCSS: '.edgeLabel rect { opacity: 1 !important; fill: #ffffff !important; }'
  flowchart:
    htmlLabels: true
    wrappingWidth: 320
    nodeSpacing: 160
    rankSpacing: 180
    curve: bumpY
---
flowchart TB
  %% DataFlow: arrows point from data origin to receiver
  n0["«external entity»<br/>Web user"]
  n1("«process»<br/>Web app<br/>#91;Presentation tier#93;")
  n2("«process»<br/>Handle web request<br/>#91;Application server#93;")
  n3["«external entity»<br/>Kafka<br/>#91;External event platform#93;"]
  n4("«process»<br/>Process incoming event<br/>#91;Application server#93;")
  n5["«data store»<br/>Application datastore<br/>#91;Oracle RAC#93;"]
  n5@{ shape: datastore }

  n0 -->|"Web request"| n1
  n1 -->|"Web response"| n0
  n1 -->|"Application request"| n2
  n2 -->|"Application response"| n1
  n3 -->|"Event record"| n4
  n4 -->|"Event-derived record"| n5

  classDef internal fill:#e7f0fb,stroke:#3c6fa9,color:#15243a
  classDef external fill:#f0f2f5,stroke:#737d8b,color:#15243a
  classDef person fill:#dbeafe,stroke:#3c6fa9,color:#15243a
  classDef store fill:#edf6f1,stroke:#37715b,color:#15243a
  class n0 external
  class n1 internal
  class n2 internal
  class n3 external
  class n4 internal
  class n5 store
```

</details>

## Data flows

| ID | From | To | Data carried | Technology |
|---|---|---|---|---|
| R01 | Web user | Web app | Web request |  |
| R02 | Web app | Web user | Web response |  |
| R03 | Web app | Handle web request | Application request |  |
| R04 | Handle web request | Web app | Application response |  |
| R05 | Kafka | Process incoming event | Event record |  |
| R06 | Process incoming event | Application datastore | Event-derived record |  |

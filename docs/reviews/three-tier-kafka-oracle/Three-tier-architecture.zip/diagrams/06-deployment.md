# Runtime placement and Oracle RAC

Logical deployment · host count and sites are open

![Compact C4 diagram](06-deployment.png)

[Interactive view](06-deployment.html) · [Scalable SVG](06-deployment.svg)

<details>
<summary>Mermaid source export</summary>

```mermaid
---
title: "Runtime placement and Oracle RAC"
config:
  theme: base
  themeVariables:
    primaryTextColor: '#15243a'
    lineColor: '#374151'
    edgeLabelBackground: '#ffffff'
  themeCSS: '.edgeLabel rect { opacity: 1 !important; fill: #ffffff !important; }'
  flowchart:
    htmlLabels: false
    wrappingWidth: 320
    nodeSpacing: 160
    rankSpacing: 180
    curve: bumpY
---
flowchart TB
  %% C4Deployment: C4 types with automatic graph layout
  subgraph n0["«deployment node»<br/>Web runtime<br/>&lbrack;Presentation tier&rbrack;"]
    n1["«container»<br/>Web app<br/>#91;Hosting style open#93;"]
  end
  subgraph n2["«deployment node»<br/>Application runtime<br/>&lbrack;Application tier&rbrack;"]
    n3["«container»<br/>Application server<br/>#91;Includes the Kafka consumer#93;"]
  end
  n4["«external system»<br/>Kafka<br/>#91;Cluster topology open#93;"]
  subgraph n5["«deployment node»<br/>Oracle RAC environment<br/>&lbrack;Data tier&rbrack;"]
    n6["«deployment node»<br/>RAC database instances<br/>#91;Instance and host count open#93;"]
    n7[("«database»<br/>Application datastore<br/>#91;One shared Oracle database#93;")]
  end

  n1 -->|"Sends web requests"| n3
  n3 -->|"Consumes events from"| n4
  n3 -->|"Connects via database<br/>service"| n6
  n6 -->|"Access the shared<br/>database"| n7

  classDef internal fill:#e7f0fb,stroke:#3c6fa9,color:#15243a
  classDef external fill:#f0f2f5,stroke:#737d8b,color:#15243a
  classDef person fill:#dbeafe,stroke:#3c6fa9,color:#15243a
  classDef deployment fill:#f6f9fc,stroke:#737d8b,color:#15243a,stroke-dasharray:4 3
  class n0 deployment
  class n1 internal
  class n2 deployment
  class n3 internal
  class n4 external
  class n5 deployment
  class n6 internal
  class n7 internal
```

</details>

## Relationships

| ID | From | To | Action | Technology | Source evidence |
|---|---|---|---|---|---|
| R01 | Web app | Application server | Sends web requests |  |  |
| R02 | Application server | Kafka | Consumes events from |  |  |
| R03 | Application server | RAC database instances | Connects via database service |  | The database service is a logical endpoint available on eligible instances. |
| R04 | RAC database instances | Application datastore | Access the shared database |  |  |

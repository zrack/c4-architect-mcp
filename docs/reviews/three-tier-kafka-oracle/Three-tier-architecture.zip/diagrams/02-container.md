# The three application tiers

The application server uses the Kafka feed and writes to Oracle

![Compact C4 diagram](02-container.png)

[Interactive view](02-container.html) · [Scalable SVG](02-container.svg)

<details>
<summary>Mermaid source export</summary>

```mermaid
---
title: "The three application tiers"
config:
  theme: base
  themeVariables:
    primaryTextColor: '#15243a'
    lineColor: '#374151'
    edgeLabelBackground: '#ffffff'
  themeCSS: '.edgeLabel rect { opacity: 1 !important; fill: #ffffff !important; }'
  flowchart:
    htmlLabels: false
    wrappingWidth: 320
    nodeSpacing: 160
    rankSpacing: 180
    curve: bumpY
---
flowchart TB
  %% C4Container: C4 types with automatic graph layout
  n0["«person»<br/>Web user<br/>#91;Business role to confirm#93;<br/>Someone using the web app. Exact<br/>role and task are open."]
  n1["«container»<br/>Web app<br/>#91;Tier 1 · Presentation#93;<br/>Receives user input; hosting<br/>style and user operations are<br/>open."]
  n2["«container»<br/>Application server<br/>#91;Tier 2 · Application#93;<br/>Handles web requests, consumes<br/>Kafka events and persists<br/>records."]
  n3["«external system»<br/>Kafka<br/>#91;Event platform#93;<br/>Carries events consumed by the<br/>application. A separate upstream<br/>eventing service is an open<br/>question."]
  n4[("«database»<br/>Application datastore<br/>#91;Tier 3 · Oracle RAC#93;<br/>One logical application<br/>datastore hosted by Oracle RAC.<br/>Schema and operational ownership<br/>are open.")]

  n0 -->|"Uses the web interface"| n1
  n1 -->|"Sends web requests"| n2
  n2 -->|"Consumes events from"| n3
  n2 -->|"Writes event-derived<br/>records"| n4

  classDef internal fill:#e7f0fb,stroke:#3c6fa9,color:#15243a
  classDef external fill:#f0f2f5,stroke:#737d8b,color:#15243a
  classDef person fill:#dbeafe,stroke:#3c6fa9,color:#15243a
  class n0 person
  class n1 internal
  class n2 internal
  class n3 external
  class n4 internal
```

</details>

## Relationships

| ID | From | To | Action | Technology | Source evidence |
|---|---|---|---|---|---|
| R01 | Web user | Web app | Uses the web interface |  |  |
| R02 | Web app | Application server | Sends web requests |  |  |
| R03 | Application server | Kafka | Consumes events from |  | A client dependency. Event records flow the other way. |
| R04 | Application server | Application datastore | Writes event-derived records |  |  |

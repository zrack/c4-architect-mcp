# System context

One application, two entry paths

![Compact C4 diagram](01-context.png)

[Interactive view](01-context.html) · [Scalable SVG](01-context.svg)

<details>
<summary>Mermaid source export</summary>

```mermaid
---
title: "System context"
config:
  theme: base
  themeVariables:
    primaryTextColor: '#15243a'
    lineColor: '#374151'
    edgeLabelBackground: '#ffffff'
  themeCSS: '.edgeLabel rect { opacity: 1 !important; fill: #ffffff !important; }'
  flowchart:
    htmlLabels: false
    wrappingWidth: 320
    nodeSpacing: 160
    rankSpacing: 180
    curve: bumpY
---
flowchart TB
  %% C4Context: C4 types with automatic graph layout
  n0["«person»<br/>Web user<br/>#91;Business role to confirm#93;<br/>Someone using the web app. Exact<br/>role and task are open."]
  n1["«software system»<br/>Event records application<br/>#91;Serves web requests and stores<br/>incoming event records#93;<br/>Working name for the<br/>application. The brief does not<br/>identify the business domain."]
  n2["«external system»<br/>Kafka<br/>#91;Event platform#93;<br/>Carries events consumed by the<br/>application. A separate upstream<br/>eventing service is an open<br/>question."]

  n0 -->|"Uses the web interface"| n1
  n2 -->|"Makes inbound events<br/>available"| n1

  classDef internal fill:#e7f0fb,stroke:#3c6fa9,color:#15243a
  classDef external fill:#f0f2f5,stroke:#737d8b,color:#15243a
  classDef person fill:#dbeafe,stroke:#3c6fa9,color:#15243a
  class n0 person
  class n1 internal
  class n2 external
```

</details>

## Relationships

| ID | From | To | Action | Technology | Source evidence |
|---|---|---|---|---|---|
| R01 | Web user | Event records application | Uses the web interface |  |  |
| R02 | Kafka | Event records application | Makes inbound events available |  | The application consumes records from the Kafka feed. |
